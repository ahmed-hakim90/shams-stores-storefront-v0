<?php
if (!defined('ABSPATH')) exit;

class Shams_Products {
    public static function register() {
        register_rest_route('shams/v1', '/products/(?P<id>\d+)/meta', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'get_meta'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route('shams/v1', '/products/(?P<id>\d+)/meta', [
            'methods' => 'PUT',
            'callback' => [__CLASS__, 'update_meta'],
            'permission_callback' => [__CLASS__, 'admin_only'],
        ]);

        register_rest_route('shams/v1', '/health', [
            'methods' => 'GET',
            'callback' => [__CLASS__, 'health_check'],
            'permission_callback' => '__return_true',
        ]);
    }

    public static function admin_only($request) {
        if (!current_user_can('manage_woocommerce')) {
            return new WP_Error('forbidden', 'Admin access required', ['status' => 403]);
        }
        return true;
    }

    public static function get_meta($request) {
        $id = intval($request->get_param('id'));
        $product = wc_get_product($id);

        if (!$product) {
            return new WP_Error('not_found', 'Product not found', ['status' => 404]);
        }

        return [
            'id' => $id,
            'meta' => [
                'installment_from' => $product->get_meta('_shams_installment_from'),
                'official' => $product->get_meta('_shams_official') === 'yes',
                'featured_video' => $product->get_meta('_shams_featured_video'),
                'size_guide' => $product->get_meta('_shams_size_guide'),
                'badge_text' => $product->get_meta('_shams_badge_text'),
            ],
        ];
    }

    public static function update_meta($request) {
        $id = intval($request->get_param('id'));
        $product = wc_get_product($id);

        if (!$product) {
            return new WP_Error('not_found', 'Product not found', ['status' => 404]);
        }

        $params = $request->get_json_params();
        $meta_map = [
            'installment_from' => '_shams_installment_from',
            'featured_video' => '_shams_featured_video',
            'size_guide' => '_shams_size_guide',
            'badge_text' => '_shams_badge_text',
        ];

        foreach ($meta_map as $param_key => $meta_key) {
            if (isset($params[$param_key])) {
                $product->update_meta_data($meta_key, sanitize_text_field($params[$param_key]));
            }
        }

        if (isset($params['official'])) {
            $product->update_meta_data('_shams_official', $params['official'] ? 'yes' : 'no');
        }

        $product->save();

        return ['success' => true, 'id' => $id];
    }

    public static function health_check($request) {
        return [
            'status' => 'ok',
            'version' => SHAMS_HEADLESS_VERSION,
            'woocommerce' => class_exists('WooCommerce') ? wc()->version : 'not_installed',
            'php' => PHP_VERSION,
            'wordpress' => get_bloginfo('version'),
            'settings' => [
                'registration' => (bool) get_option('shams_headless_allow_registration', true),
                'wishlist' => (bool) get_option('shams_headless_enable_wishlist', true),
                'reviews' => (bool) get_option('shams_headless_enable_reviews', true),
                'require_phone' => (bool) get_option('shams_headless_require_phone', true),
                'token_expiry_days' => intval(get_option('shams_headless_token_expiry_days', 7)),
            ],
        ];
    }
}
