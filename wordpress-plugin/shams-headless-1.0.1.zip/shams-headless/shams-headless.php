<?php
/**
 * Plugin Name: Shams Stores Headless Control
 * Description: Full control panel for headless storefront — auth, customers, orders, products, settings
 * Version: 1.0.1
 * Author: Shams Stores
 * Text Domain: shams-headless
 * Requires PHP: 7.4
 * Requires at least: 5.8
 */

if (!defined('ABSPATH')) exit;

if (version_compare(PHP_VERSION, '7.4', '<')) {
    add_action('admin_notices', function() {
        echo '<div class="notice notice-error"><p>Shams Headless requires PHP 7.4 or higher.</p></div>';
    });
    return;
}

define('SHAMS_HEADLESS_VERSION', '1.0.1');
define('SHAMS_HEADLESS_PATH', plugin_dir_path(__FILE__));
define('SHAMS_HEADLESS_URL', plugin_dir_url(__FILE__));

require_once SHAMS_HEADLESS_PATH . 'includes/class-token.php';
require_once SHAMS_HEADLESS_PATH . 'includes/class-auth.php';
require_once SHAMS_HEADLESS_PATH . 'includes/class-customer.php';
require_once SHAMS_HEADLESS_PATH . 'includes/class-products.php';
require_once SHAMS_HEADLESS_PATH . 'includes/class-orders.php';
require_once SHAMS_HEADLESS_PATH . 'includes/class-admin.php';
require_once SHAMS_HEADLESS_PATH . 'includes/class-cors.php';

class Shams_Headless {
    private static $instance = null;

    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('init', [$this, 'load_textdomain']);
        add_action('rest_api_init', [$this, 'register_routes']);
    }

    public function load_textdomain() {
        load_plugin_textdomain('shams-headless', false, dirname(plugin_basename(__FILE__)) . '/languages');
    }

    public function register_routes() {
        if (!class_exists('WooCommerce')) {
            return;
        }
        Shams_Auth::register();
        Shams_Customer::register();
        Shams_Products::register();
        Shams_Orders::register();
    }
}

function shams_headless_activate() {
    $defaults = [
        'cors_origins' => home_url(),
        'token_expiry_days' => 7,
        'allow_registration' => true,
        'require_phone' => true,
        'enable_wishlist' => true,
        'enable_reviews' => true,
    ];
    foreach ($defaults as $key => $value) {
        if (get_option("shams_headless_{$key}") === false) {
            update_option("shams_headless_{$key}", $value);
        }
    }
}

register_activation_hook(__FILE__, 'shams_headless_activate');
Shams_Headless::instance();
